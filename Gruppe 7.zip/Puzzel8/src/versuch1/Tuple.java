package versuch1;

public class Tuple {
	private int x;
	private int y;
	
	public Tuple(int a, int b) {
		this.x = a;
		this.y = b;
	}
	
	// Getter
	public int getX() {
		return this.x;
	}
	
	public int getY() {
		return this.y;
	}
}
